function verTrabajo(idTrabajo){
	window.location.href = idTrabajo + '.html';
}



